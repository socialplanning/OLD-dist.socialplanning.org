request_started = object()
request_finished = object()
got_request_exception = object()
