from django.contrib import admin
from basic.inlines.models import *


admin.site.register(InlineType)