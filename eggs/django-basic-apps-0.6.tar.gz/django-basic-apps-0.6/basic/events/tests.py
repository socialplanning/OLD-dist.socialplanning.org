"""
>>> from django.test import Client
>>> from basic.events.models import *
>>> from django.core.urlresolvers import reverse

>>> client = Client()

"""