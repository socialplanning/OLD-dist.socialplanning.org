ClockQueue Package Readme
=========================

Overview
--------

ClockQueue is a library that provides some basic classes for creating asyncronous job queues for use with ClockServer
