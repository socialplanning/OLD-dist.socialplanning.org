five.localsitemanager
=====================

Overview
--------

``five.localsitemanager`` provides a local site manager based on the
standard Zope 3 local site manager for Zope 2.

Changes
-------

See CHANGES.txt.

Installation
------------

See INSTALL.txt.

Developer Resources
-------------------

- Subversion browser:

  http://svn.zope.org/five.localsitemanager

- Read-only Subversion checkout:

  $ svn co svn://svn.zope.org/repos/main/five.localsitemanager/trunk

- Writable Subversion checkout:

  $ svn co svn+ssh://svn.zope.org/repos/main/five.localsitemanager/trunk
