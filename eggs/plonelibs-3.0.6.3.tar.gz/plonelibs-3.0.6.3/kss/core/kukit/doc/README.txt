=====
kukit
=====

More documentation...
---------------------

General information

  o Authors: see doc/CREDITS.txt

  o License: see doc/LICENSE.txt

License
-------

Unless otherwise stated, kukit is released under the GNU GPL version 2
license. See doc/LICENSE.txt for the license text. 
