
Save sour selenium tests into this directory, in html format.
All the tests ending with .html will be processed automatically.

