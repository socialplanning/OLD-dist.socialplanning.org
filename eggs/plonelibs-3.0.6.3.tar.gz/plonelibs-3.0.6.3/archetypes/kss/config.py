
PROJECTNAME = 'archetypes.kss'
SKINS_DIR = 'skins'

GLOBALS = globals()

