from Products.PloneTestCase import PloneTestCase as ptc
ptc.setupPloneSite()

class FormTestCase(ptc.PloneTestCase):
    pass

class FormFunctionalTestCase(ptc.FunctionalTestCase):
    pass