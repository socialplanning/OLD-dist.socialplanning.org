
// bind collapsible sections on load


kukit.actionsGlobalRegistry.register("initializeCollapsible", function (oper) {
        activateCollapsibles();
    });

kukit.log('Plone legacy [initializeCollapsible] action registered.');

