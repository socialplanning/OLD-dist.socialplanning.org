from todoplug import Todo

def test_some_important_thing():
    raise Todo("Not done yet")

def test_something_else():
    pass
