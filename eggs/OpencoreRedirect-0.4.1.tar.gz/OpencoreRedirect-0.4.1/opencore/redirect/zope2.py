#

def initialize(context):
    """Intializer called when used as a Zope 2 product."""
