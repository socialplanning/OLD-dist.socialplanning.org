This is a fork of the project on google code:
http://code.google.com/p/python-bitly/

The reason for the fork is to package it up with setuptools.
