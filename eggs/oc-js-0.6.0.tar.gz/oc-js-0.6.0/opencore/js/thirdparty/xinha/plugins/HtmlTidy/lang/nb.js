// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "HTML Tidy": "HTML Tidy",
  "Tidy failed.  Check your HTML for syntax errors.": "Tidy feilet. Sjekk HTML koden for syntaksfeil."
};