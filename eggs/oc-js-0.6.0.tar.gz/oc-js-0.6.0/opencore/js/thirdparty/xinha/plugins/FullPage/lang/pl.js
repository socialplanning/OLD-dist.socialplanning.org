// I18N for the FullPage plugin
// LANG: "pl", ENCODING: UTF-8
// translated: Krzysztof Kotowicz, koto1sa@o2.pl, http://www.eskot.krakow.pl/portfolio
{
  "Alternate style-sheet:": "Alternatywny arkusz stylów:",
  "Background color:": "Kolor tła:",
  "Cancel": "Anuluj",
  "DOCTYPE:": "DOCTYPE:",
  "Document properties": "Właściwości dokumentu",
  "Document title:": "Tytuł dokumentu:",
  "OK": "OK",
  "Primary style-sheet:": "Arkusz stylów:",
  "Text color:": "Kolor tekstu:",
  "Character set:": "Zestaw znaków",
  "Description:": "Opis",
  "Keywords:": "Słowa kluczowe",
  "UTF-8 (recommended)": "UTF-8 (zalecany)"
};
