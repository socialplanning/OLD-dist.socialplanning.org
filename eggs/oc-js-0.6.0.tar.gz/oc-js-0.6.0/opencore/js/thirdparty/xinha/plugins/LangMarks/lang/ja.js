// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "language select": "言語の選択",
  "&mdash; language &mdash;":	"&mdash; 言語 &mdash;",
  "Greek": "ギリシャ語",
  "English": "英語",
  "French": "フランス語",
  "Latin": "ラテン語"
};