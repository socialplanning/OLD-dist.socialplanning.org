// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Chars": "文字数",
  "Words": "単語数",
  "... in progress": "... 処理中"
};