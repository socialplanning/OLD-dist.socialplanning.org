// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "You have unsaved changes in the editor": "Vous n'avez pas enregistré vos modifications"
};
