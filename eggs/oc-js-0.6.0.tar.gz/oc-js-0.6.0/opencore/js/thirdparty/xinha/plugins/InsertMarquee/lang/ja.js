// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Marquee Editor": "マーキーエディタ",
  "Name/ID:": "名前/ID",
  "Insert scrolling marquee": "スクロールマーキーの挿入",
  "Insert marquee": "マーキーの挿入",
  "Direction:": "方向:",
  "Behavior:": "動作:",
  "Text:": "テキスト:",
  "Background-Color:": "背景色:",
  "Width:": "幅:",
  "Height:": "高さ:",
  "Speed Control": "速度調整",
  "Scroll Amount:": "スクロール量:",
  "Scroll Delay:": "スクロール遅延:",
  "Cancel": "中止",
  "Continuous": "左右連続",
  "Slide": "スライド",
  "Alternate": "折り返し",
  "You must enter the form name": "名前の入力が必要です"
};