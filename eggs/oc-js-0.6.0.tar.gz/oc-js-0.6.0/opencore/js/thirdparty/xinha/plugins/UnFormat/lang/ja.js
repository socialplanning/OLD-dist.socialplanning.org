// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Page Cleaner": "ページクリーナー",
  "Cleaning Area": "クリーニング領域",
  "Selection": "選択部分",
  "All": "すべて",
  "Cleaning options": "クリーニングオプション",
  "Formatting:": "書式指定タグ:",
  "All HTML:": "全HTMLタグ:",
  "Select which types of formatting you would like to remove.": "削除する書式を選択してください。"
};