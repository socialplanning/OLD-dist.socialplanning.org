This is from PyDispatcher <http://pydispatcher.sf.net>

It was moved here because installation of PyDispatcher conflicts with
RuleDispatch (they both use the dispatch top-level module), and I
thought it would be easier to just put it here.  Also, PyDispatcher is
small and stable and doesn't need updating often.

If the name conflict is resolved in the future, this package can go
away.
