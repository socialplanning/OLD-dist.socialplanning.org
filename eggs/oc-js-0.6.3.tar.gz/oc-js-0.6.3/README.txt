=======
 oc-js
=======

This is the omnibus package for general opencore relate javascript and
related maintenance scripts and utilities (packing, compression, etc).

If using without opencore, do the following to install::

   $ cd oc-js; python setup.py develop
   $ python setup.py zinstall /path/to/zopeinstance

If you are using a opencore style ENV setups, path is not required.
