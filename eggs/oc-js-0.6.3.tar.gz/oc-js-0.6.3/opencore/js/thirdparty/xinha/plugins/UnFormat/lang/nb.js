// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "Page Cleaner": "Dokumentvasker",
  "Cleaning Area": "Vaskeområde",
  "Selection": "Markert område",
  "All": "Hele dokumentet",
  "Cleaning options": "Vaskemetoder",
  "Formatting:": "Formattering:",
  "All HTML:": "All HTML-kode:",
  "Select which types of formatting you would like to remove.": "Velg hva slags formattering du ønsker å fjerne."
};