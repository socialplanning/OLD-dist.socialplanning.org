// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Edit HTML for selected text": "選択中テキストのHTMLを編集します",
  "Tag Editor": "タグエディタ"
};