// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "Alternate style-sheet:": "Alternativt stilsett:",
  "Background color:": "Bakgrunnsfarge:",
  "Cancel": "Avbryt",
  "DOCTYPE:": "DOCTYPE:",
  "Keywords:": "Nøkkelord",
  "Description:": "Beskrivelse",
  "Character set:": "Tegnsett",
  "Document properties": "Egenskaper for dokument",
  "Document title:": "Tittel på dokument:",
  "OK": "OK",
  "Primary style-sheet:": "Stilsett:",
  "Text color:": "Tekstfarge:"
};