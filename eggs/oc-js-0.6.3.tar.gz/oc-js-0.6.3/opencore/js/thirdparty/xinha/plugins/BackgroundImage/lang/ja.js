// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Set page background image": "ページの背景画像を設定",
  "Set Page Background Image": "ページの背景画像を設定",
  "Remove Current Background": "現在の背景画像を除去",
  "Cancel": "中止"
};