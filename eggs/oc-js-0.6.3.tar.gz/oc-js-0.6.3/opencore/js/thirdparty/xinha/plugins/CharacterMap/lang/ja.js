// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Insert special character": "特殊文字を挿入",
  "Cancel": "中止"
};