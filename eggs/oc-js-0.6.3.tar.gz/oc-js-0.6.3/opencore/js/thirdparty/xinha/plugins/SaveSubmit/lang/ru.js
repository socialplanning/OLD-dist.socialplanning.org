// I18N constants
// LANG: "ru", ENCODING: UTF-8
// Simple job done by Alexey Kirpichnikov <alexkir at kiwistudio dot ru>
{ 
	"Save": "Сохранить",
	"Saving...": "Сохранение...",
	"in progress": "пожалуйста, ждите",
	"Ready": "Готово"
};