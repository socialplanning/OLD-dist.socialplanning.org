plone.mail Package Readme
=========================

Overview
--------

A package containing a few methods to assist in handling and creating messages with encoded content
